#include <stdio.h>
#include <stdlib.h>

#ifndef boolean 
 #define boolean int
 #define true 1
 #define false 0
#endif

//#define kRamSize ( 64 * 1024 )

