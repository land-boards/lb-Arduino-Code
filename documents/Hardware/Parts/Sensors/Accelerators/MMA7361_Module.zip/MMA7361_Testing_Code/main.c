//-------------------------------------------------------------------
// MMA7361 Demo code, show the 3 axis date through UART periodically
// Hardware connection:	X_out           PC2
//			Y_out	        PC1
//        		Z_out	        PC0
//			MMA7361_En	PC3
//			UART_Tx 	PD1
// Software UART baudrate 115200 when main frequency is 4M
//-------------------------------------------------------------------
												
#include "iom168.h"
#include "inAVR.h"
#include "stdio.h"
#include "stdbool.h"

#define Max_Axis	3
#define X_Channel	0	//PC2
#define Y_Channel       1	//PC1
#define Z_Channel	2	//PC0
#define MMA7361_EN	0x08	//PC3

const unsigned char Channel_Tbl[Max_Axis]={0x42,0x41,0x40};     //Z,Y,X
const unsigned char Axis_Name[Max_Axis]={'X','Y','Z'};
unsigned char Temp, Temp1, ADC_Done,ShowDebug_Cnt;              //Temporary saving cells
unsigned int Axis_Data[Max_Axis];
unsigned long SumReg = 0;					//Storage variable
static char	SampCnt;                                        //ADC samples counter

#include	"functions.c"

int main(void)
{
  unsigned char i;
  IO_Ports_Init();				//Initialize IO ports
  Timers_Init();				//Initialize timers
  ADC_Init();					//Initialize ADC
  PRR = 0x82;                                   //Reduce consumption 86 (don't stop SPI)
  CLKPR = 0x80;					//Increase Fcpu
  CLKPR = 0x00;
  TCCR2B = 0x06;

  __disable_interrupt();
  __watchdog_reset();
    WDTCSR = 0x18;				//Enable watchdog, timeout 256ms
    WDTCSR = 0x0D;
  __enable_interrupt();				//Enable interrupts
  
  MMA7361_Init();
  while(1)
  {
    __watchdog_reset();				//Reset watchdog timer
      
    if(ShowDebug_Cnt==0)							
    {
    	ShowDebug_Cnt=30;//13;  				//Get data periodically
    	for(i=0;i<Max_Axis;i++)					//Get Axis data 
  			Axis_Data[i]=Get_ADC(i,10);
  		for(i=0;i<Max_Axis;i++)				//Show Axis data through UART
  		{
    		SW_UART_Tx(Axis_Name[i]);
  			Put_Axis(Axis_Data[i]);
    		SW_UART_Tx(' ');
  		}
    	SW_UART_Tx(' ');					//Next Line
    	SW_UART_Tx(0x0d);
  	}
  }
  
  
}

//SIGNAL(SIG_OVERFLOW2)
#pragma vector=TIMER2_OVF_vect

__interrupt void TMR2irq( void )

{
  if(ShowDebug_Cnt!=0)
  	ShowDebug_Cnt--;
}

//SIGNAL(SIG_ADC)
#pragma vector=ADC_vect

__interrupt void ADCirq( void )
{
  SumReg += ADC; 								//Add result to common sum
  if(--SampCnt == 0)								//Check number of samples
  {
	ADC_Done=1;								//Measuring is complete
	ADCSRA = 0x80;							        //Stop ADC
  }
  else
  {
	ADCSRA |= 0x40;								//Start next ADC cycle
  }
}

//SIGNAL(__vector_default)
//#pragma vector=default

