# Modified AD9833 Waveform Generator with Arduino Nano / Pro Mini
Modified version of "AD9833 Waveform Generator" from http://www.vwlowen.co.uk/arduino/AD9833-waveform-generator/AD9833-waveform-generator.htm

I made some adjustments to make the GUI look and feel better.
Support for a DS3231 RTC was added too.
Additionally a 3D-Model of a 3D-printable Case designed by me and some images are available on Thingiverse (https://www.thingiverse.com/thing:2999358).
