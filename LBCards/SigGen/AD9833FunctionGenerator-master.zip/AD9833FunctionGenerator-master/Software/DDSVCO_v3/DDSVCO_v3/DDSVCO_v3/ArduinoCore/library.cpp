/*
 * ArduinoCore.cpp
 *
 * Created: 05-12-2018 11:51:50 PM
 * Author : chris
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

