# AD9833_arduino
Control AD9833 module from arduino.
