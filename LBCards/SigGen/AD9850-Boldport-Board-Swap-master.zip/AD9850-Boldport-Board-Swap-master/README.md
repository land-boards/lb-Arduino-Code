### AD9850 Signal Generator Boldport Board Swap Version

This is the KiCAD files and Gerber files for the Boldport Board Swap.  It is a driver board for an AD9850 module. It uses an  ATMega328p as the controll chip and includes a display as well as two rotary encoders to support a UI.

It is based on the project:

http://www.vwlowen.co.uk/arduino/AD9850-waveform-generator/AD9850-waveform-generator.htm

Which in turn is based on AD9851 code from Andrew Smallbone - modified for AD9850 http://www.rocketnumbernine.com/2011/10/25/programming-the-ad9851-dds-synthesizer
