# 036-tbhs-Solder-Reflow-Oven
Ben turns an infrawave toaster oven into a solder reflow oven that can be used with PCB's.
