Readme
******
1. Please use the Diptrace version 2.2 RC1 or 2.1.9 Beta to open/edit the schematic & layout file. 
Newer files are not backward compatible with older version of Diptrace.